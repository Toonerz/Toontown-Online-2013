To get the files:
Place parameters.txt, and start_TTO in your TTO Client, and use the launcher. The launcher will download the new files needed from the download server,
after you've got the files, launch the start_TTO.bat file and use that as the way to start up the game from now on after that.
(ALSO, DELETE libpandadx8 & 9 AFTER YOU GOT THE FILES FROM THE LAUNCHER!!!)

To start up the datagram server:
Go to stunnel>bin>stunnel.exe and start it up. Then start the server with Server1-Initalize.bat.

Then you're basically finished, have fun. :)
