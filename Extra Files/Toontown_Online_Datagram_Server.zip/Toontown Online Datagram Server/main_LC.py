#DEVLOPMENT SERVER - USES SSL PORT 7000 AND NORMAL PORT 6668 
import ctypes
ctypes.windll.kernel32.SetConsoleTitleA("Datagram Server")

from pandac.PandaModules import ConfigVariableString
ConfigVariableString('window-type', 'none').setValue('none')

from pandac.PandaModules import *
from ToontownMsgTypes import *
from OtpDoGlobals import *
#from direct.showbase.directObject import directObject
from direct.task import Task
from direct.directbase import DirectStart
from direct.distributed.ServerRepository import ServerRepository
from direct.distributed.ClientRepository import ClientRepository
from direct.distributed.ClockDelta import *
from direct.distributed.ConnectionRepository import ConnectionRepository
from direct.distributed.PyDatagram import PyDatagram
from direct.distributed.PyDatagramIterator import PyDatagramIterator
from direct.distributed import DistributedObject
from datetime import datetime
import time
import sched
CLIENT_SET_ZONE = 29 # Doesn't exist in MsgTypes.py

from pandac.PandaModules import ConfigVariableString

ConfigVariableString('window-type', 'none').setValue('none')

DC_FILE_NAMES = ["etc/otp.dc", "etc/toon.dc"]

CLOSED = False
SERVER_VERSION = 'sv1.0.47.38'

#from ai import AIRepo


class Client:

    def __init__(self, connection, netAddress, channelId):
        self.connection = connection
        self.netAddress = netAddress
        self.ourChannel = channelId
        self.explicitInterestLocations = {}
        self.currentInterestLocations = set()
        self.objectsByDoId = {}
        self.objectsByLocation = {}
        self.DISL = {}

class Object:

    def __init__(self, doId, parentId, zoneId, dclass):
        self.doId = doId
        self.parentId = parentId
        self.zoneId = zoneId
        self.dclass = dclass

class ToonTownServerRepository(ServerRepository):

    notify = directNotify.newCategory('ToonTownServerRepository')

    def __init__(self):
        PORT = base.config.GetInt('server-port', 6668)
        ServerRepository.__init__(self, PORT, None, dcFileNames=DC_FILE_NAMES)
        #ServerRepository.__init__(self, PORT, None, dcFileNames=[])
        self.clientsByConnection = {}
        self.clientsByChannelId = {}
        self.locationToClients = {}
        self.objectsByLocation = {}
        self.clientsByDISL = {}
        self.setTcpHeaderSize(2)
        self.connectionList = []
        clock = ClockDelta()
        print 'Server initialized, listening for datagrams'
        #dclass = self.dclassesbyName[]
        dclass = self.dclassesByNumber[148]
        #field = dclass.getField(0)
        print dclass
        #print field
        
    #Does the same thing as the orinigal one execpt sending the doId range datagram which is completely unknown for the Toontown Client. ~LC
    def listenerPoll(self, task):
        if self.qcl.newConnectionAvailable():
            rendezvous = PointerToConnection()
            netAddress = NetAddress()
            newConnection = PointerToConnection()
            retVal = self.qcl.getNewConnection(rendezvous, netAddress,
                                               newConnection)
            if not retVal:
                return task.cont

            # Crazy dereferencing
            newConnection = newConnection.p()

            #  Add clients information to dictionary
            id = self.idAllocator.allocate()
            doIdBase = id * self.doIdRange + 1

            self.notify.info(
                "Got client %s from %s" % (doIdBase, netAddress))

            client = self.Client(newConnection, netAddress, doIdBase)
            self.clientsByConnection[client.connection] = client
            self.clientsByDoIdBase[client.doIdBase] = client

            # Now we can start listening to that new connection.
            self.qcr.addConnection(newConnection)
            
            self.lastConnection = newConnection
            #self.sendDoIdRange(client)
            
        return task.cont

    def handleDatagram(self, dg):
        if not dg.getLength() > 0:
            return None
        dgi = PyDatagramIterator(dg)
        connection = dg.getConnection()
        msgType = dgi.getUint16()
        if msgType == CLIENT_HEARTBEAT:
            self.notify.debug('Recieved heartbeat.')
        elif msgType == CLIENT_DISCONNECT:
            #self.handleClientDisconnect(connection)
            if connection in self.connectionList:
                self.connectionList.remove(connection)
            #return None
        elif msgType == CLIENT_SET_ZONE:
            self.handleSetZone(dgi, connection)
        elif msgType == CLIENT_REMOVE_ZONE:
            self.handleRemoveZone(dgi, connection)
        elif msgType == CLIENT_CREATE_OBJECT_REQUIRED:
            self.handleClientCreateObjectRequired(dg, dgi)
        elif msgType == CLIENT_OBJECT_UPDATE_FIELD:
            #self.handleClientUpdateField(dg, dgi)
            #print dgi
            doId = dgi.getUint32()
            fieldId = dgi.getUint16()
            print "Got field update for doId = %d and fieldId = %d" % (doId, fieldId)
            #print fieldId
            
            if doId == OTP_DO_ID_CENTRAL_LOGGER and fieldId == 329:
                print "Got CentralLogger Message: %s, %s" % (dgi.getString(), dgi.getString())
            
            if doId == 433103088 and fieldId == 597:
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_OBJECT_UPDATE_FIELD)
                datagram.addUint32(433103088) #doId
                #datagram.addUint16(589)#fieldId
                datagram.addUint16(594)#fieldId
                datagram.addUint32(1)
                datagram.addUint32(1)
                datagram.addUint32(1)
                self.cw.send(datagram, connection)

            if doId == 433103088 and fieldId == 600:
                print "Got SpeedChat Phrase"
                SC = dgi.getUint16()
                print SC
                if SC == 905:
                    datagram = PyDatagram()
                    datagram.addUint16(CLIENT_OBJECT_UPDATE_FIELD)
                    datagram.addUint32(433103088) #doId
                    datagram.addUint16(595)
                    self.cw.send(datagram, connection)
            
            if doId == 433103090 and fieldId == 619:
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_OBJECT_UPDATE_FIELD)
                datagram.addUint32(doId)
                datagram.addUint16(611)
                datagram.addUint32(1)
                self.cw.send(datagram, connection)
                
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_OBJECT_UPDATE_FIELD)
                datagram.addUint32(doId)
                datagram.addUint16(610)
                datagram.addString("waitCountdown")
                datagram.addInt16(0)
                self.cw.send(datagram, connection)
                
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_OBJECT_UPDATE_FIELD)
                datagram.addUint32(doId)
                datagram.addUint16(610)
                datagram.addString("leaving")
                datagram.addInt16(0)
                self.cw.send(datagram, connection)
                
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_OBJECT_UPDATE_FIELD)
                datagram.addUint32(doId)
                datagram.addUint16(622)
                datagram.addUint32(123456789)
                datagram.addInt16(0)
                self.cw.send(datagram, connection)
                
            if doId == OTP_DO_ID_TOONTOWN_CODE_REDEMPTION_MANAGER and fieldId == 2227:
                code = dgi.getString()
                
                print "Recived book code: %s" % (code)
                
        elif msgType == CLIENT_OBJECT_DELETE:
            self.handleClientDeleteObject(dg, dgi.getUint32())
        elif msgType == CLIENT_OBJECT_DISABLE:
            self.handleClientDisable(dg, dgi.getUint32())
        elif msgType == CLIENT_ADD_INTEREST:
            #self.handleClientAddInterest(self, Client, dgi)
            
            handle = dgi.getUint16()
            contextId = dgi.getUint32()
            parentId = dgi.getUint32()
            zoneList = [dgi.getUint32()]  
            print 'Network :: Interest -> (%d, %d, %d %s)' % (handle, contextId, parentId, zoneList)
            while True:
                remainingData = (dg.getLength() - dgi.getCurrentIndex())
                if remainingData == 0:
                    break
                zoneList.append(dgi.getUint32())
            if zoneList == [3]: #Found shard list interest
                datagram = PyDatagram()
                #dclass = self.dclassesByName['DistributedDistrict']
                #dclass = self.dclassesByNumber[10]
                #field = dclass.getField(0)
                #print field
                datagram.addUint16(CLIENT_CREATE_OBJECT_REQUIRED_RESP)
                datagram.addUint32(4618) #parentId
                datagram.addUint32(3) #zoneId
                #datagram.addUint16(10) # DistributedDistrict Dclass field
                datagram.addUint16(58) #ToontownDistrict DClass Field
                datagram.addUint32(316000000) #Shard ID (doId)
                datagram.addString('Nuttyboro') #District name
                datagram.addUint8(1) # 1 - Enabled 0 - Disabled

                datagram.addBool(0)
                self.cw.send(datagram, connection)
                
                datagram = PyDatagram()
                #dclass = self.dclassesByName['DistributedDistrict']
                #dclass = self.dclassesByNumber[10]
                #field = dclass.getField(0)
                #print field
                datagram.addUint16(CLIENT_CREATE_OBJECT_REQUIRED_RESP)
                datagram.addUint32(4618) #parentId
                datagram.addUint32(3) #zoneId
                #datagram.addUint16(10) # DistributedDistrict Dclass field
                datagram.addUint16(58) #ToontownDistrict DClass Field
                datagram.addUint32(317000000) #Shard ID (doId)
                datagram.addString('Nutty River') #District name
                datagram.addUint8(1) # 1 - Enabled 0 - Disabled

                datagram.addBool(0)
                self.cw.send(datagram, connection)
            if parentId == 316000000 and zoneList == [2]:
                #This sets the NewsManager to the latest news issue.  Without this, it'll crash the game!
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_CREATE_OBJECT_REQUIRED_RESP)
                datagram.addUint32(4618) #parentId
                datagram.addUint32(3) #zoneId
                datagram.addUint16(387) #ToontownDistrict DClass Field
                datagram.addUint32(900000000) #Shard ID (doId)
                datagram.addString("2013-08-22 23:49:46")
                self.cw.send(datagram, connection)
                
                #This sets the DistributedToon's ArrivedOnDistrict field to the correct District ID.
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_OBJECT_UPDATE_FIELD)
                datagram.addUint32(1) #doId
                datagram.addUint16(112) #fieldId
                datagram.addUint32(316000000)
                self.cw.send(datagram, connection)
                
                datagran2 = PyDatagram()
                datagran2.addUint16(CLIENT_CREATE_OBJECT_REQUIRED_RESP)
                datagran2.addUint32(0)
                datagran2.addUint32(0)
                datagran2.addUint16(172)
                datagran2.addUint32(637100008)
                arg = []
                datagran2.addUint16(len(arg) << 1)
                for i in arg:
                    datagran2.addInt16(int(i))
                datagran2.addUint16(len(arg) << 1)
                for i in arg:
                    datagran2.addInt16(int(i))
                datagran2.addUint16(len(arg) << 1)
                for i in arg:
                    datagran2.addInt16(int(i))
                datagran2.addUint16(len(arg) << 1)
                for i in arg:
                    datagran2.addInt16(int(i))
                #arg = [64, 65, 66, 10, 15]
                datagran2.addUint16(len(arg))
                for i in arg:
                    datagran2.addUint16(int(i))
                self.cw.send(datagran2, connection)
            
            #if parentId == 316000000 and zoneList == [1]:
                #datagram = PyDatagram()
                #datagram.addUint16(CLIENT_OBJECT_UPDATE_FIELD)
                #datagram.addUint32(1) #doId
                #datagram.addUint16(112) #fieldId
                #datagram.addUint32(316000000)
                #self.cw.send(datagram, connection)
                
                '''
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_CREATE_OBJECT_REQUIRED_OTHER_RESP)
                datagram.addUint32(316000000) #parentId
                datagram.addUint32(2) #zoneId
                #datagram.addUint16(83)
                datagram.addUint16(64)
                datagram.addUint32(433103088)
                datagram.addString("")
                datagram.addString("")
                datagram.addInt16(0)
                self.cw.send(datagram, connection)
                '''
            datagram = PyDatagram()
            datagram.addUint16(CLIENT_DONE_INTEREST_RESP)
            datagram.addUint16(handle)
            datagram.addUint32(contextId)
            datagram.addUint32(parentId)
            for zoneId in zoneList:
                datagram.addUint32(zoneId)
            self.cw.send(datagram, connection)
            
        elif msgType == CLIENT_REMOVE_INTEREST:
            handle = dgi.getUint16()
            datagram = PyDatagram()
            datagram.addUint16(CLIENT_DONE_INTEREST_RESP)
            datagram.addUint16(handle)
            self.cw.send(datagram, connection)
            #return None
        elif msgType == CLIENT_LOGIN_TOONTOWN:
            self.connectionList.append(connection)
            #message = PyDatagram()
            #message.addUint16(CLIENT_SYSTEM_MESSAGE)
            #message.addString('Closed for maintenance')
            #message.addString('A surprise is awaiting for you if you finished your toon. ~LC')
            #self.cw.send(message, connection)
            ###self.handleClient3Login(dgi, connection)
            self.handleClientLoginToontown(dgi, connection)
            #datagram = PyDatagram()
            #datagram.addUint16(CLIENT_GO_GET_LOST) #Tells the client to "GO GET LOST" of course. :P
            #datagram.addUint16(151) #Makes the user see the logged out by Admin message
            #datagram.addString('Closed for maintenance') #String that's viewable in the log
            #self.cw.send(datagram, connection)
        elif msgType == CLIENT_LOGIN:
            print dgi
            datagram = PyDatagram()
            datagram.addUint16(CLIENT_LOGIN_RESP)
            datagram.addUint8(0)
            self.cw.send(datagram, connection)
        elif msgType == CLIENT_GET_AVATARS:
            self.handleGetAvatars(dgi, connection)
        elif msgType == CLIENT_CREATE_AVATAR:
            #return None
            datagram = PyDatagram()
            datagram.addUint16(CLIENT_CREATE_AVATAR_RESP)
            datagram.addUint16(0) #echoContext
            datagram.addUint8(0) #returnCode
            datagram.addUint32(1)
            self.cw.send(datagram, connection)
        elif msgType == CLIENT_SET_NAME_PATTERN:
            datagram = PyDatagram()
            #patternOne = dgi.getInt16
            #patternTwo = dgi.getInt16
            #patternThree = dgi.getInt16
            #patternFour = dgi.getInt16
            #patternFive = dgi.getInt16
            #patternSix = dgi.getInt16
            #patternSeven = dgi.getInt16
            #print patternOne
            #print patternTwo
            #print patternThree
            #print patternFour
            #print patternFive
            #print patternSix
            #print patternSeven
            datagram.addUint16(CLIENT_SET_NAME_PATTERN_ANSWER)
            datagram.addUint32(1)
            datagram.addUint8(0)
            self.cw.send(datagram, connection)
        #elif msgType == CLIENT_SET_AVATAR:
        elif msgType == CLIENT_SET_AVATAR:
            #try:
                packer = DCPacker()
                dclass = self.dclassesByName['DistributedToon']
                otpdclass = self.dclassesByName['DistributedPlayer']
                avId = dgi.getUint32()
                if avId == 0:
					datagram = PyDatagram()
					datagram.addUint16(CLIENT_OBJECT_DISABLE)
					datagram.addUint32(1)
					self.cw.send(datagram, connection)
					return None
                datagram = PyDatagram()
                print "Getting toon details from avId %d" % (avId)
                #datagram.addUint16(CLIENT_GET_AVATAR_DETAILS_RESP)
                datagram.addUint16(15) #CLIENT_GET_AVATAR_DETAILS_RESP Msgtype
                datagram.addUint32(1)
                datagram.addUint8(0)
                datagram.addString('Felis Catus') #Toon name
                datagram.addString('Unknown')
                datagram.addUint32(0) #TODO: Find out how to correctly send an uint32uint8array field update since this placeholder skips most of the fields!           
                datagram.addBool(1) #setAsGM
				
#                datagram.addString('t\x05\x01\x00\x01\x70\x1b\x33\x1b\31\x1b\x14\x00\x14\x14') #DNA (blob)
						#1st = speices, 14 = blue
                datagram.addString('t\x05\x01\x01\x01\x04\x0a\x04\x0a\x0d\x1b\x1a\x00\x1a\x1a') #DNA (blob)
                datagram.addUint8(0) #GM			  #TS TSC SL  SLC
                datagram.addUint16(10000) #Max Bank
                datagram.addUint16(10000) #Current Bank
                datagram.addUint16(250) #Max Jellybeans
                datagram.addUint16(250) #Current Jellybeans
                datagram.addUint16(137) #Max Laff
                datagram.addUint16(137) #Current Laff
                datagram.addUint32(0) #Battle ID
                datagram.addString('Unknown') #Experience (blob)
                datagram.addUint8(80) #Max Gag Carry
                #datagram.addUint8(7) #amount of items in your array

                #setTrackAccess

                field = dclass.getField(13)
                print field
                arg = [1, 1, 1, 1, 1, 1, 1]
                datagram.addUint16(len(arg) << 1)
                for i in arg:
                    datagram.addInt16(int(i))

                
                #packer.beginPack(field)
                #field.packArgs(packer, [[0, 0, 0, 0, 1, 1, 0]])
                #if not packer.endPack():
                #    pass
                #datagram.appendData(packer.getString())


                datagram.addInt8(20) #Track Progress 1
                datagram.addUint32(20) #Track Progress 2
                #setTrackBonusLevel

                field = dclass.getField(15)
                print field

                arg = [-1, -1, -1, -1, -1, -1, -1]
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addInt8(int(i))
                
                #packer.beginPack(field)
                #field.packArgs(packer, [[0, 0, 0, 0, 1, 1, 0]])
                #if not packer.endPack():
                #    pass
                #datagram.appendData(packer.getString())

                datagram.addString('') #setInventory

                #setMaxNPCFriends (Uint16)

                datagram.addUint16(16)
                
                #field = dclass.getField(17)
                #print field
                #packer.beginPack(field)
                #field.packArgs(packer, [6])
                #if not packer.endPack():
                #    pass
                #datagram.appendData(packer.getString())
                
                #setNPCFriendsDict(uint32uint8array) Then again.. It worked. ._.

                arg = []
                datagram.addUint16(len(arg) * 5)
                for i in arg:
                    datagram.addUint32(int(i))

                #datagram.addUint8(1)
                #field = dclass.getField(18)
                #print field
                #packer.beginPack(field)
                #field.packArgs(packer, [[1, 2, 3]])
                #if not packer.endPack():
                #    pass
                #datagram.appendData(packer.getString())

                datagram.addUint32(316000000) #setDefaultShard

                datagram.addUint32(2000) #setDefaultZone

                datagram.addString('')

                #setZonesVisited (uint32array) SKIPPED

                field = dclass.getField(22)
                print field

                arg = [1000, 2000, 3000, 4000, 5000, 6000, 9000]
                datagram.addUint16(len(arg) << 2)
                for i in arg:
                    datagram.addUint32(int(i))

                
                #packer.beginPack(field)
                #field.packArgs(packer, [[1000, 2000]])
                #if not packer.endPack():
                #    pass
                #datagram.appendData(packer.getString())

                #setHoodsVisited (uint32array) SKIPPED
                
                field = dclass.getField(23)
                print field
                

                arg = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 11000, 12000, 13000]
                datagram.addUint16(len(arg) << 2)
                for i in arg:
                    datagram.addUint32(int(i))

                datagram.addString('') #setInterface

                datagram.addUint32(9000) #setLastHood

                datagram.addUint8(1) #setTutorialAck

                datagram.addUint32(25) #setMaxClothes

                #setClothesTopsList(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))


                #field = dclass.getField(26)
                #print field
                #packer.beginPack(field)
                #field.packArgs(packer, [[]])
                #if not packer.endPack():
                #    pass
                #datagram.appendData(packer.getString())

                #setClothesBottomsList(uint8array)
                #setClothesBottomsList(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                datagram.addUint32(0) #setMaxAccessories

                #setHatList(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setGlassessList(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setBackpackList(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setShoesList(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                datagram.addUint8(14) #number
                datagram.addUint8(0) #tex
                datagram.addUint8(0) #tex

                datagram.addUint8(0) #setGlasses 1
                datagram.addUint8(0) #setGlasses 2
                datagram.addUint8(0) #setGlasses 3

                datagram.addUint8(0) #setBackpack 1
                datagram.addUint8(0) #setBackpack 2
                datagram.addUint8(0) #setBackpack 3

                datagram.addUint8(0) #setShoes 1
                datagram.addUint8(0) #setShoes 2
                datagram.addUint8(0) #setShoes 3

                datagram.addString('')

                #setEmoteAccess(uint8array)

                arg = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setCustomMeeages(uint16array)

                arg = []
                datagram.addUint16(len(arg) << 1)
                for i in arg:
                    datagram.addUint16(int(i))

                datagram.addString('') #setResistanceMessages

                #setPetTrickPhrases(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                datagram.addUint16(0) #setCatalogSchedule 1
                datagram.addUint32(0) #setVatalogSchedule 2

                datagram.addString('') #setCatalog 1
                datagram.addString('') #setCatalog 2
                datagram.addString('') #setCatalog 3

                datagram.addString('') #setMailBoxContents

                datagram.addString('') #SetDeliverySchedule

                datagram.addString('') #setGiftSchedule

                datagram.addString('') #setAwardMailboxContents

                datagram.addString('') #setAwardSchedule

                datagram.addUint8(0) #setAwardNotify

                datagram.addUint8(0) #setCatalogNotify 1

                datagram.addUint8(0) #setCatalogNotify 2

                datagram.addUint8(0) #setSpeedChatStyleIndex

                #setTeleportAccess (uint32array)

                arg = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 11000, 12000, 13000]
                datagram.addUint16(len(arg) << 2)
                for i in arg:
                    datagram.addUint32(int(i))

                #setCogStatus (uint32array)
                #arg = []
                arg = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
                datagram.addUint16(len(arg) << 2)
                for i in arg:
                    datagram.addUint32(int(i))

                #setCogCount (uint32array)
                arg = []
                datagram.addUint16(len(arg) << 2)
                for i in arg:
                    datagram.addUint32(int(i))

                #setCogRadar(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setBuildingRadar(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setCogLevels(uint8array)

                arg = [0, 0, 0, 0]
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setCogTypes(uint8array)

                arg = [0, 0, 0, 0]
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setCogParts (uint32array)
                arg = [17, 14, 12, 10]
                datagram.addUint16(len(arg) << 2)
                for i in arg:
                    datagram.addUint32(int(i))

                #setCogMerits(uint16array)

                arg = [100, 60, 40, 20]
                datagram.addUint16(len(arg) << 1)
                for i in arg:
                    datagram.addUint16(int(i))

                datagram.addUint32(0) #setHouseId

                #setQuests (uint32array)
                arg = []
                datagram.addUint16(len(arg) << 2)
                for i in arg:
                    datagram.addUint32(int(i))

                #setQuestHistory(uint16array)

                arg = []
                datagram.addUint16(len(arg) << 1)
                for i in arg:
                    datagram.addUint16(int(i))

                datagram.addUint8(0) #setRewardHistory 1

                #setRewardHistory 2(uint16array)

                arg = []
                datagram.addUint16(len(arg) << 1)
                for i in arg:
                    datagram.addUint16(int(i))


                datagram.addUint8(4) #setQuestCarryLimit

                datagram.addInt16(0) #setCheesyEffect 1
                datagram.addUint32(0) #setCheesyEffect 2
                datagram.addUint32(0) #setCheesyEffect 3

                datagram.addUint8(0) #setPosIndex

                #setFishCollection 1(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setFishCollection 2(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setFishCollection 3(uint16array)

                arg = []
                datagram.addUint16(len(arg) << 1)
                for i in arg:
                    datagram.addUint16(int(i))

                datagram.addUint8(20) #setMaxFishTank

                #setFishTank 1(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setFishTank 2(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setFishTank 3(uint16array)

                arg = []
                datagram.addUint16(len(arg) << 1)
                for i in arg:
                    datagram.addUint16(int(i))

                datagram.addUint8(0) #setFishingRod

                #setFishingTrophies(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setFlowerCollection 1(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setFlowerCollection 2(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setFlowerBasket 1(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                #setFlowerBasket 2(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                datagram.addUint8(25) #setMaxFlowerBasket

                #setGardenTrophies(uint8array)

                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                datagram.addUint8(1) #setShovel

                datagram.addUint32(0) #setShovelSkill

                datagram.addUint8(1) #setWateringCan

                datagram.addUint32(0) #setWateringCanSkill

                datagram.addUint32(0) #setPetID

                datagram.addUint8(0) #setPetTutorialDone

                datagram.addUint8(0) #setFishBingoTutorialDone

                datagram.addUint8(0) #setFishBingoMarkTutorialDone

                datagram.addInt8(0) #setKartBodyType

                datagram.addInt8(0) #setKartBodyColor

                datagram.addInt8(0) #setKartAccessoryColor

                datagram.addInt8(0) #setKartEngineBlockType

                datagram.addInt8(0) #setKartSpoilerType

                datagram.addInt8(0) #setKartFrontWheelWellType

                datagram.addInt8(0) #setKartBackWheelWellType

                datagram.addInt8(0) #setKartRimType

                datagram.addInt8(0) #setKartDecalType

                datagram.addUint32(100) #setTickets

                datagram.addUint8(0) #setKartingHistory 1
                datagram.addUint8(0) #setKartingHistory 2
                datagram.addUint8(0) #setKartingHistory 3
                datagram.addUint8(0) #setKartingHistory 4
                datagram.addUint8(0) #setKartingHistory 5
                datagram.addUint8(0) #setKartingHistory 6
                datagram.addUint8(0) #setKartingHistory 7
                datagram.addUint8(0) #setKartingHistory 8
                datagram.addUint8(0) #setKartingHistory 9
                datagram.addUint8(0) #setKartingHistory 10
                datagram.addUint8(0) #setKartingHistory 11
                datagram.addUint8(0) #setKartingHistory 12
                datagram.addUint8(0) #setKartingHistory 13
                datagram.addUint8(0) #setKartingHistory 14
                datagram.addUint8(0) #setKartingHistory 15
                datagram.addUint8(0) #setKartingHistory 16

                
                datagram.addUint8(0) #setKartingTrophies 1
                datagram.addUint8(0) #setKartingTrophies 2
                datagram.addUint8(0) #setKartingTrophies 3
                datagram.addUint8(0) #setKartingTrophies 4
                datagram.addUint8(0) #setKartingTrophies 5
                datagram.addUint8(0) #setKartingTrophies 6
                datagram.addUint8(0) #setKartingTrophies 7
                datagram.addUint8(0) #setKartingTrophies 8
                datagram.addUint8(0) #setKartingTrophies 9
                datagram.addUint8(0) #setKartingTrophies 11
                datagram.addUint8(0) #setKartingTrophies 11
                datagram.addUint8(0) #setKartingTrophies 12
                datagram.addUint8(0) #setKartingTrophies 13
                datagram.addUint8(0) #setKartingTrophies 14
                datagram.addUint8(0) #setKartingTrophies 15
                datagram.addUint8(0) #setKartingTrophies 16
                datagram.addUint8(0) #setKartingTrophies 17
                datagram.addUint8(0) #setKartingTrophies 18
                datagram.addUint8(0) #setKartingTrophies 19
                datagram.addUint8(0) #setKartingTrophies 20
                datagram.addUint8(0) #setKartingTrophies 21
                datagram.addUint8(0) #setKartingTrophies 22
                datagram.addUint8(0) #setKartingTrophies 23
                datagram.addUint8(0) #setKartingTrophies 24
                datagram.addUint8(0) #setKartingTrophies 25
                datagram.addUint8(0) #setKartingTrophies 26
                datagram.addUint8(0) #setKartingTrophies 27
                datagram.addUint8(0) #setKartingTrophies 28
                datagram.addUint8(0) #setKartingTrophies 29
                datagram.addUint8(0) #setKartingTrophies 30
                datagram.addUint8(0) #setKartingTrophies 31
                datagram.addUint8(0) #setKartingTrophies 32
                datagram.addUint8(0) #setKartingTrophies 33

                datagram.addUint32(0) #setKartingPersonalBest 1
                datagram.addUint32(0) #setKartingPersonalBest 2
                datagram.addUint32(0) #setKartingPersonalBest 3
                datagram.addUint32(0) #setKartingPersonalBest 4
                datagram.addUint32(0) #setKartingPersonalBest 5
                datagram.addUint32(0) #setKartingPersonalBest 6

                datagram.addUint32(0) #setKartingPersonalBest2 1
                datagram.addUint32(0) #setKartingPersonalBest2 2
                datagram.addUint32(0) #setKartingPersonalBest2 3
                datagram.addUint32(0) #setKartingPersonalBest2 4
                datagram.addUint32(0) #setKartingPersonalBest2 5
                datagram.addUint32(0) #setKartingPersonalBest2 6
                datagram.addUint32(0) #setKartingPersonalBest2 7
                datagram.addUint32(0) #setKartingPersonalBest2 8
                datagram.addUint32(0) #setKartingPersonalBest2 9
                datagram.addUint32(0) #setKartingPersonalBest2 10
                datagram.addUint32(0) #setKartingPersonalBest2 11
                datagram.addUint32(0) #setKartingPersonalBest2 12

                #setKartAccessoriesOwned [16]
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)
                datagram.addInt8(0)

                #setCogSummonsEarned
                arg = []
                datagram.addUint16(len(arg))
                for i in arg:
                    datagram.addUint8(int(i))

                datagram.addUint8(0) #setGardenStart

                #setGolfHistory [18]
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)
                datagram.addUint16(0)

                #setPackedGolfHoleBest [18]
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)

                #setGolfCourseBest
                datagram.addUint8(0)
                datagram.addUint8(0)
                datagram.addUint8(0)

                datagram.addUint8(0) #setPinkSlips

                datagram.addUint8(13) #setNametagStyle
                
                
                #datagram.addUint8([7,7,7,7,7,7,7]) #TrackNBonusLevel
                #datagram.addString('\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00') #Inventory
                #datagram.addUint8(0) #Garden started?
                #datagram.addUint16(1) #Golf History
                self.cw.send(datagram, connection)
            #except:
            #    datagram = PyDatagram()
            #    datagram.addUint16(CLIENT_GO_GET_LOST)
            #    datagram.addUint16(101)
            #    datagram.addString("An server releated error has occurred.")
            #    self.cw.send(datagram, connection)

                
        elif msgType == CLIENT_SET_WISHNAME:
            #print dgi
            avId = dgi.getUint16()
            unknown = dgi.getString()
            pendingName = dgi.getString()
            print pendingName
            if pendingName == 'Chuck Norris':
                message = PyDatagram()
                message.addUint16(CLIENT_SYSTEM_MESSAGE)
                message.addString("You can't name your toon 'Chuck Norris'. Chuck Norris NAMES YOU!")
                self.cw.send(message, connection)
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_SET_WISHNAME_RESP)
                datagram.addUint32(avId)
                datagram.addUint16(0)
                datagram.addString('NO')
                datagram.addString('NO')
                datagram.addString('')
            #import NameFilter # My attempt to make the blacklist real time. :P
            divide = pendingName.split(' ')
            lenStr = len(divide)
            s = 0
            while s != lenStr:
                nameCheck = divide[s]
                s += 1
            with open ("arrBad.txt", "r") as badWordFile:
                data=badWordFile.readlines()
                for word in data:
                    chrList = list(word)
                    if chrList.count('\n') == 1:
                        chrList.remove('\n')
                    badWord = ''.join(chrList)
                    if nameCheck == badWord:
                        print 'Bad name dectected!'
                        datagram = PyDatagram()
                        datagram.addUint16(CLIENT_SET_WISHNAME_RESP)
                        datagram.addUint32(avId)
                        datagram.addUint16(0)
                        datagram.addString('NO')
                        datagram.addString('NO')
                        datagram.addString('')
                        message = PyDatagram()
                        message.addUint16(CLIENT_SYSTEM_MESSAGE)
                        message.addString('Sorry, That name is not allowed.')
                        self.cw.send(message, connection)
                    else:
                        datagram = PyDatagram()
                        datagram.addUint16(CLIENT_SET_WISHNAME_RESP)
                        datagram.addUint32(avId)
                        datagram.addUint16(0)
                        datagram.addString('NO')
                        datagram.addString('')
                        datagram.addString('NO')
                        self.cw.send(datagram, connection)

        elif msgType == CLIENT_OBJECT_LOCATION:
            doId = dgi.getUint32()
            parentId = dgi.getUint32()
            zoneId = dgi.getUint32()
            print 'Network :: Location -> (%d, %d, %d)' % (doId, parentId, zoneId)
            if zoneId == 2000:
                #DistributedMickey
                '''
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_CREATE_OBJECT_REQUIRED_RESP)
                datagram.addUint32(316000000) #parentId
                datagram.addUint32(2) #zoneId
                datagram.addUint16(65)
                datagram.addUint32(433103088)
                datagram.addString("")
                datagram.addString("")
                datagram.addInt16(0)
                self.cw.send(datagram, connection)
                '''
                #DistributedTrolley
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_CREATE_OBJECT_REQUIRED_RESP)
                #datagram.addUint32(433103090) #doId
                datagram.addUint32(316000000) #parentId
                #datagram.addUint32(316000000)
                datagram.addUint32(5) #zoneId
                datagram.addUint16(83) #dclassId
                datagram.addUint32(433103090) #doId
                #datagram.addUint16(610) #Set Other FieldId
                #datagram.addString("waitEmpty")
                #datagram.addInt16(0)
                self.cw.send(datagram, connection)
                
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_OBJECT_UPDATE_FIELD)
                datagram.addUint32(433103090) #doId
                datagram.addUint16(610) #fieldId
                datagram.addString("waitEmpty")
                datagram.addInt16(0)
                self.cw.send(datagram, connection)
            if zoneId == 1000:
				datagram = PyDatagram()
				datagram.addUint16(CLIENT_CREATE_OBJECT_REQUIRED_RESP)
				datagram.addUint32(316000000) #parentId
				datagram.addUint32(2) #zoneId
				#datagram.addUint16(83)
				datagram.addUint16(108)
				datagram.addUint32(433103088)
				datagram.addString("SailingEast")
				datagram.addInt16(ClockDelta().getRealNetworkTime())
                
				self.cw.send(datagram, connection)
				
            if zoneId == 123456789:
				datagram = PyDatagram()
				datagram.addUint16(CLIENT_CREATE_OBJECT_REQUIRED_RESP)
				datagram.addUint32(316000000) #parentId
				datagram.addUint32(2) #zoneId
				#datagram.addUint16(83)
				datagram.addUint16(119)
				
				self.cw.send(datagram, connection)
        elif msgType == 1000: #Exclusive msgType for sending public system messages from the administrators (Will be adding security later. :P)
            print 'Got Server message request'
            message = dgi.getString()
            print message
            datagram = PyDatagram()
            datagram.addUint16(CLIENT_SYSTEM_MESSAGE)
            datagram.addString(message)
            for client in self.connectionList:
                #if client not in exceptionList:
                    #print i
                self.cw.send(datagram, client)
        elif msgType == 1001: #Send a message back to the client. :P
            print 'Got client Server message request'
            message = dgi.getString()
            print message
            datagram = PyDatagram()
            datagram.addUint16(CLIENT_SYSTEM_MESSAGE)
            datagram.addString(message)
            self.cw.send(datagram, connection)

        elif msgType == 2000:
            word = dgi.getString()
            if word == "BadSecurityFTL":
                self.notify.warning("EVERYONE'S BEEN LOGGED OUT DUE TO A DATAGRAM!")
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_GO_GET_LOST)
                datagram.addUint16(151)
                datagram.addString("You have been logged out by an administrator working on the servers.")

                for client in self.connectionList:
                #if client not in exceptionList:
                    #print i
                    self.cw.send(datagram, client)
            else:
                datagram = PyDatagram()
                datagram.addUint16(CLIENT_GO_GET_LOST)
                datagram.addUint16(126)
                datagram.addString("Nice try. >:(")
                self.cw.send(datagram, connection)
            
        elif msgType == 120: #Rewrittens Login Cookie Datagram
            print dgi
        elif msgType == 111:
            #print dgi
            self.handleClient3Login(dgi, connection)
        elif msgType == CLIENT_SYSTEMMESSAGE_AKNOWLEDGE:
            print 'Test'
        else:
            kick = PyDatagram()
            kick.addUint16(CLIENT_GO_GET_LOST)
            kick.addUint16(124)
            kick.addString('An unknown datagram was sent to the server.')
            self.notify.warning('Got a datagram %d; but could not handle it.' % msgType)

    def readDCFile(self, dcFileNames):
        print 'Loading DC files'
        dcFile = self.dcFile
        dcFile.clear()
        self.dclassesByName = {}
        self.dclassesByNumber = {}
        self.hashVal = 0
        dcImports = {}
        if dcFileNames:
            searchPath = DSearchPath()
            searchPath.appendDirectory(Filename('.'))
            for dcFileName in dcFileNames:
                pathname = Filename(dcFileName)
                vfs.resolveFilename(pathname, searchPath)
                readResult = dcFile.read(pathname)
        self.hashVal = dcFile.getHash()
        for i in range(dcFile.getNumClasses()):
            dclass = dcFile.getClass(i)
            number = dclass.getNumber()
            className = dclass.getName() + self.dcSuffix
            self.dclassesByName[className] = dclass
            if number >= 0:
                self.dclassesByNumber[number] = dclass

    def handleClientLoginToontown(self, di, conn):
        if(CLOSED == True):
            dg = PyDatagram()
            dg.addUint16(CLIENT_GO_GET_LOST)
            dg.addUint16(151)
            dg.addString('The servers are currently closed for maintenance.')
            self.cw.send(dg, conn)
        else:
            token = di.getString()
            sv = di.getString()
            if (sv != SERVER_VERSION):
                self.notify.warning('Client mismatch with server, booting.')
                dg = PyDatagram()
                dg.addUint16(CLIENT_GO_GET_LOST)
                dg.addUint16(124)
                dg.addString('Client and Server mismatch. Server is running ' + SERVER_VERSION + ', while client was running ' + sv + '.')
                self.cw.send(dg, conn)
            else:
                now = datetime.now
                dg = PyDatagram()
                dg.addUint16(CLIENT_LOGIN_TOONTOWN_RESP)
                dg.addUint8(0) #Return Code
                dg.addString('OK') #respString
                dg.addUint32(123456) #Account Number
                dg.addString('PlaceHolder') #Account Name
                dg.addUint8(1) #accountNameApproved
                dg.addString('YES') #self.openChatEnabled
                dg.addString('YES') #self.createFriendsWithChat
                dg.addString('YES') #chatCodeCreationRule
                dg.addUint32(time.time()) #sec?
                dg.addUint32(time.clock()) #usec?
                dg.addString('FULL') #self.isPaid
                dg.addString('YES') #WhiteListReponse
                dg.addString(time.strftime('%Y-%m-%d'))#lastLoggedInStr
                dg.addInt32(0) #accountDays
                dg.addString('NO_PARENT_ACCOUNT')
                dg.addString('PlaceHolder')
                self.cw.send(dg, conn) #TODO: Parse and return unique info.

    def handleClientLogin(self, dgi, connection):
        datagram = PyDatagram()
        datagram.addUint16(CLIENT_LOGIN_RESP)
        playToken = dgi.getString()
        serverVersion = dgi.getString()
        #validateDownload = dgi.getString()
        #wantMagicWords = dgi.getString()
        datagram.addUint8(0) # return code
        datagram.addString('All ok') # description
        datagram.addUint32(100000001) # DISL id
        datagram.addString('Guest100000001') # D-Code/account name
        datagram.addUint8(0) # custom D-Code
        datagram.addString('YES')
        datagram.addString('YES')
        datagram.addString('YES')
        datagram.addString(':R')
        datagram.addUint32(0) # second
        datagram.addUint32(0) # unsigned second
        datagram.addString('FULL') # membership
        datagram.addString('1969-12-31 12:00:00') # login date string
        datagram.addInt32(720) # account days
        datagram.addString('NO_PARENT_ACCOUNT') # account type
        datagram.addString('unknown') # game username
        self.cw.send(datagram, connection)
        if not connection in self.connectionList:
            self.connectionList.append(connection)

    def handleClient3Login(self, dgi, connection): #DO NOT EDIT THIS. VERY UNSTABLE
        datagram = PyDatagram()
        playToken = dgi.getString()
        print playToken
        print self.connectionList
        
        datagram.addUint16(CLIENT_LOGIN_3_RESP)
        datagram.addInt8(0) #returnCode
        datagram.addString("All OK") #errorString
        datagram.addString("YES") #openChatEnabled
        datagram.addString("YES") #createFriendsWithChat
        datagram.addString("YES") #chatCodeCreation
        datagram.addString("FULL") #access
        datagram.addInt32(32) #familyAccountId
        datagram.addInt32(32) #playerAccountId
        datagram.addString("LittleToonCat") #playerName
        datagram.addInt8(1) #playerNameApproved
        datagram.addInt32(6) #maxAvatars

        '''
        dgT = PyDatagram()
        dgT.addUint16(CLIENT_LOGIN_3_RESP)
        dgT.addInt8(0)
        dgT.addString('YES')
        dgT.addString('YES')
        dgT.addString('YES')
        dgT.addString('VELVET')
        dgT.addString('VELVET')
        dgT.addInt32(1234)
        dgT.addInt32(1234)
        dgT.addString('Commander')
        dgT.addInt8(1)
        dgT.addInt32(2)
        dgT.addUint16(0)
        dgT.addUint32(1)
        dgT.addUint32(0)
        self.cw.send(dgT, connection)
        
        datagram.addUint16(CLIENT_LOGIN_3_RESP)
        datagram.addUint8(0) #Return Code
        #datagram.addString('') #Error String
        datagram.addString('YES') #Enable Open Chat (SpeedChat+?)
        datagram.addString('YES') #Create Friends with Chat
        datagram.addString('YES') #chatCodeCreation
        datagram.addString('FULL') #Access String
        datagram.addString('FULL') #Access String
        datagram.addString('')
        datagram.addUint32(2)
        datagram.addUint32(3)
        datagram.addString('*')
        datagram.addUint8(1) #Name Approved
        datagram.addUint32(6) #Max Toons
        '''	
        self.cw.send(datagram, connection)
        #message = PyDatagram()
        #message.addUint16(CLIENT_SYSTEM_MESSAGE)
        #message.addString("ADMIN: If the server goes down, do not be alarmed, it's only us doing some work on it.")#I just edited this ~ Dalmatian 1:40PM (Central Time) 12/10/2013
        #self.cw.send(message, connection)

    def handleClient2Login(self, dgi, connection):
        datagram = PyDatagram()
        datagram.addUint16(CLIENT_LOGIN_2_RESP)
        datagram.addUint8(0) #Return Code
        datagram.addString('All ok') #Error String
        datagram.addString('UserName')
        datagram.addUint8(1) #Can Chat
        datagram.addUint32(0) #Sec
        datagram.addUint32(0) #usec
        datagram.addUint8(1) #Paid
        datagram.addString('')
        datagram.addString('YES') #Use Whitelist
        self.cw.send(datagram, connection)

    def handleGetAvatars(self, dgi, connection):
        datagram = PyDatagram()
        datagram.addUint16(CLIENT_GET_AVATARS_RESP)
        datagram.addUint8(0) # return code
        datagram.addUint16(0) # number of avatars
        #Start Avatar List
        '''
        datagram.addUint32(1) # avatar id
        datagram.addString('Toon') # avatar name
        #The following strings are simply name parts.
        datagram.addString('') #Name Under Review
        datagram.addString('') #Name Accecpted (Place name here)
        datagram.addString('') #Name Rejected
        datagram.addString('t\x05\x01\x00\x01\x39\x1b\x33\x1b\31\x1b\x12\x00\x14\x14') # dna string (net string)
        datagram.addUint8(0) # avatar list position
        datagram.addUint8(0) # name status
        
        datagram.addUint32(250000002) # avatar id
        datagram.addString('Toon') # avatar name
        #The following strings are simply name parts.
        datagram.addString('') #Name Under Review
        datagram.addString('') #Name Accepted (Place name here)
        datagram.addString('') #Name Rejected
        datagram.addString('t\x05\x02\x00\x01\x39\x1b\x33\x1b\31\x1b\x14\x00\x14\x14') # dna string (net string)
        datagram.addUint8(1) # avatar list position
        datagram.addUint8(0) # name status
        #datagram.addUint32(250000003) # avatar id
        #datagram.addString('Sonic the Hedge-toon') # avatar name
        #The following strings are simply name parts.
        #datagram.addString('') #Name Under Review
        #datagram.addString('') #Name Accepted (Place name here)
        #datagram.addString('') #Name Rejected
        #datagram.addString('t\x06\x02\x00\x01\x39\x1b\x33\x1b\31\x1b\x14\x00\x14\x14') # dna string (net string)
        #datagram.addUint8(2) # avatar list position
        #datagram.addUint8(0) # name status
		'''
        #End Avatar list
        self.cw.send(datagram, connection)

    def handleClientObjectLocation(self, datagram, dgi):
        doId = dgi.getUint32()
        parentId = dgi.getUint32()
        zoneId = dgi.getUint32()
        connection = datagram.getConnection()
        client = self.clientsByConnection[connection]
        object = client.objectsByChannelId.get(doId)
        if not object:
            return None
        self.setObjectLocation(client, object, parentId, zoneId)

    def handleClientAddInterest(self, client, dgi):
        handle = dgi.getUint16()
        if handle not in client.explicitInterestLocations.keys():
            client.explicitInterestLocations[handle] = {}
        contextId = dgi.getUint32()
        parentId = dgi.getUint32()
        zoneIdList = [dgi.getUint32()]
        while dgi.getRemainingSize():
            zoneIdList.append(dgi.getUint32())
        client.explicitInterestLocations[handle][contextId] = set([parentId, zoneIdList])
        for zoneId in zoneIdList:
            self.locationToClients.setdefault((parentId, zoneId), set()).add(client)
            for object in self.objectsByLocation[(parentId, zoneId)]:
                self.cw.send(self.createObjectWithRequiredOther(object), client.connection)
        datagram = PyDatagram()
        datagram.addUint16(CLIENT_DONE_INTEREST_RESP)
        datagram.addUint16(handle)
        datagram.addUint32(contextId)
        self.cw.send(datagram, client.connection)

class ToonTownAIRepository(ClientRepository):

    notify = directNotify.newCategory('ToonTownAIRepository')

    def __init__(self):
        ClientRepository.__init__(self, dcFileNames=[], dcSuffix='AI')
        PORT = base.config.GetInt('server-port', 6668)
        self.connect([URLSpec('http://localhost:%s' % PORT)],
                      successCallback=self.connectSuccess,
                      failureCallback=self.connectFailure)


    def connectFailure(self, statusCode, statusString):
        raise StandardError, statusString

    def connectSuccess(self):
        self.acceptOnce('gotCreateReady', self.getCreateReady)

    def getCreateReady(self):
        self.setInterestZones([3])
        
    def handleDatagram(self, di):
		print di


simbase = ToonTownServerRepository()
simbase.air = ToonTownAIRepository()

run()
